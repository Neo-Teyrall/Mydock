class Factory:
    class Lapin:
        def _init__(self):
            self.name = "lapin"
    class Cochon:
        def __init__(self,mod):
            self.mod
            self.name = "cochon"
            Factory.self.M
        def M(Factory,self):
            
            pass
    def __init__(self,clef):
        Factory.Lapin.clef = clef
        Factory.Cochon.clef = clef
        
if __name__ == "__main__" :
    F = Factory("001")
    a = Factory.Cochon()
    b = Factory.Lapin()
    print(a.clef, b.clef)
